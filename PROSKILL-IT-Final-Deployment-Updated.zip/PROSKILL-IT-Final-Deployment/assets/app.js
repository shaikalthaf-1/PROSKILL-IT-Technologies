(() => {
  'use strict';
  const doc = document;
  const root = doc.documentElement;
  const body = doc.body;
  const qs = (selector, context = doc) => context.querySelector(selector);
  const qsa = (selector, context = doc) => [...context.querySelectorAll(selector)];

  // Mobile navigation
  const menu = qs('[data-menu]');
  const closeMenu = () => {
    body.classList.remove('nav-open');
    if (menu) {
      menu.setAttribute('aria-expanded', 'false');
      menu.innerHTML = '<svg class="icon" aria-hidden="true"><use href="assets/icons.svg#i-menu"></use></svg>';
    }
  };
  if (menu) menu.addEventListener('click', (event) => {
    event.stopPropagation();
    const open = !body.classList.contains('nav-open');
    body.classList.toggle('nav-open', open);
    menu.setAttribute('aria-expanded', String(open));
    menu.innerHTML = `<svg class="icon" aria-hidden="true"><use href="assets/icons.svg#${open ? 'i-close' : 'i-menu'}"></use></svg>`;
  });
  qsa('[data-nav-toggle]').forEach((btn) => btn.addEventListener('click', () => {
    if (window.innerWidth <= 1050) {
      const item = btn.closest('.nav-item');
      const open = item.classList.toggle('open');
      btn.setAttribute('aria-expanded', String(open));
    }
  }));
  doc.addEventListener('click', (event) => {
    const header = qs('.site-header');
    const clickedInsideHeader = header && event.composedPath().includes(header);
    if (window.innerWidth <= 1050 && body.classList.contains('nav-open') && !clickedInsideHeader) closeMenu();
  });
  doc.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeMenu(); });

  // Light/dark theme with a black/white toggle symbol.
  const themeButtons = qsa('[data-theme-toggle]');
  const preferredDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const savedTheme = localStorage.getItem('proskill-theme');
  const applyTheme = (theme) => {
    root.dataset.theme = theme;
    const dark = theme === 'dark';
    themeButtons.forEach((button) => {
      const label = dark ? 'Switch to light theme' : 'Switch to dark theme';
      button.setAttribute('aria-label', label);
      button.setAttribute('aria-pressed', String(dark));
      const labelNode = qs('[data-theme-label]', button);
      if (labelNode) labelNode.textContent = label;
    });
    const themeMeta = qs('meta[name="theme-color"]');
    if (themeMeta) themeMeta.content = dark ? '#05070d' : '#0b1530';
  };
  applyTheme(savedTheme || (preferredDark ? 'dark' : 'light'));
  themeButtons.forEach((button) => button.addEventListener('click', () => {
    const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('proskill-theme', next);
    applyTheme(next);
  }));

  // Accordions
  qsa('[data-accordion]').forEach((button) => button.addEventListener('click', () => {
    const item = button.closest('.accordion, .faq-item');
    if (!item) return;
    const open = item.classList.toggle('open');
    button.setAttribute('aria-expanded', String(open));
  }));

  // Program category filter — uses the native hidden attribute for reliable display.
  const filterButtons = qsa('[data-filter]');
  const courseCards = qsa('[data-course-category]');
  const filterStatus = qs('[data-filter-status]');
  const applyFilter = (filter) => {
    let visible = 0;
    courseCards.forEach((card) => {
      const show = filter === 'All' || card.dataset.courseCategory === filter;
      card.hidden = !show;
      card.classList.toggle('hidden', !show);
      if (show) {
        visible += 1;
        card.classList.add('visible');
      }
    });
    filterButtons.forEach((button) => {
      const active = button.dataset.filter === filter;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    if (filterStatus) filterStatus.textContent = filter === 'All'
      ? `Showing all ${visible} programs.`
      : `Showing ${visible} ${filter} program${visible === 1 ? '' : 's'}.`;
  };
  filterButtons.forEach((button) => button.addEventListener('click', () => applyFilter(button.dataset.filter)));

  // Practical course recommendation tool.
  const finderSection = qs('[data-finder]');
  if (finderSection) {
    const form = qs('[data-finder-form]', finderSection) || qs('form', finderSection);
    const result = qs('[data-finder-result]', finderSection);
    const recommendations = {
      software: {url:'java-full-stack.html', name:'Java Full Stack Development', reason:'Best for structured enterprise software development across backend, APIs, databases, and React interfaces.', icon:'java'},
      web: {url:'mern-stack.html', name:'MERN Stack Development', reason:'Best for a JavaScript-first route into responsive web applications and modern product development.', icon:'react'},
      data: {url:'data-science-ai.html', name:'Data Science & Artificial Intelligence', reason:'Best for analytics, Python, machine learning, visualisation, and applied AI workflows.', icon:'python'},
      cloud: {url:'aws-devops.html', name:'AWS Cloud & DevOps Engineering', reason:'Best for cloud operations, infrastructure automation, CI/CD, containers, and deployment reliability.', icon:'aws'},
      qa: {url:'software-testing.html', name:'Software Testing — Manual & Automation', reason:'Best for a practical entry into quality engineering, test design, API testing, and Selenium automation.', icon:'selenium'},
      crm: {url:'salesforce.html', name:'Salesforce Admin & Developer', reason:'Best for CRM administration, business automation, Apex, Lightning components, and platform development.', icon:'salesforce'}
    };
    if (form && result) {
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }
        const values = Object.fromEntries(new FormData(form).entries());
        const rec = recommendations[values.role];
        if (!rec) return;
        const levelNote = values.experience === 'new'
          ? 'Start with the foundation modules and guided practice before moving to the capstone work.'
          : values.experience === 'working'
            ? 'Use the foundation modules as a skills check, then focus on projects, architecture, and interview evidence.'
            : 'Begin with a short foundation review, then progress into the applied modules and portfolio projects.';
        const modeNote = values.mode === 'Classroom'
          ? 'Ask admissions for the next Hyderabad or Bangalore classroom batch.'
          : values.mode === 'Live online'
            ? 'Ask admissions for the next instructor-led live-online batch.'
            : 'Compare current classroom and live-online schedules before choosing.';
        result.innerHTML = `<div class="finder-recommendation"><span class="finder-tech"><img src="assets/tech/${rec.icon}.svg" alt=""></span><div><small>Recommended starting point</small><strong>${rec.name}</strong><span>${rec.reason}</span><p>${levelNote} ${modeNote}</p></div></div><div class="finder-result-actions"><a class="btn btn-primary btn-sm" href="${rec.url}">View program <svg class="icon icon-sm" aria-hidden="true"><use href="assets/icons.svg#i-arrow"></use></svg></a><a class="btn btn-outline btn-sm" href="contact.html?program=${rec.url.replace('.html','')}">Ask an advisor</a></div>`;
        result.hidden = false;
        result.classList.add('show');
        result.focus({preventScroll:true});
        result.scrollIntoView({behavior:'smooth', block:'nearest'});
      });
      form.addEventListener('reset', () => {
        result.hidden = true;
        result.classList.remove('show');
        result.innerHTML = '';
      });
    }
  }

  // Auto-select a program when arriving from a course page.
  const params = new URLSearchParams(window.location.search);
  const programSelect = qs('select[name="program"]');
  if (programSelect && params.get('program')) {
    const requested = params.get('program');
    if ([...programSelect.options].some((option) => option.value === requested)) programSelect.value = requested;
  }

  // Deployment-ready enquiry: validate and open a pre-filled WhatsApp conversation.
  qsa('[data-enquiry-form]').forEach((form) => form.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }
    const data = Object.fromEntries(new FormData(form).entries());
    if (data.website) return; // honeypot
    const programText = form.elements.program?.selectedOptions?.[0]?.textContent || data.program || 'Not specified';
    const lines = [
      'Hello PROSKILL IT, I would like free career counselling.',
      '',
      `Name: ${data.name}`,
      `Phone: ${data.phone}`,
      `Email: ${data.email}`,
      `City: ${data.city}`,
      `Program: ${programText}`,
      `Preferred mode: ${data.mode}`,
      data.message ? `Question: ${data.message}` : ''
    ].filter(Boolean);
    const message = qs('.form-message', form);
    if (message) message.classList.add('show');
    const whatsappUrl = `https://wa.me/919010213122?text=${encodeURIComponent(lines.join('\n'))}`;
    window.open(whatsappUrl, '_blank', 'noopener');
  }));

  // Progressive reveal; content remains visible when IntersectionObserver is unavailable.
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    }), {threshold:0.08, rootMargin:'0px 0px -30px'});
    qsa('.reveal').forEach((element) => observer.observe(element));
  } else {
    qsa('.reveal').forEach((element) => element.classList.add('visible'));
  }

  qsa('[data-year]').forEach((element) => { element.textContent = new Date().getFullYear(); });
})();
