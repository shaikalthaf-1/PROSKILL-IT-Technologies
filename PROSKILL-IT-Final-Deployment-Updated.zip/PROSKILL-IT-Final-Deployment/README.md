# PROSKILL IT Technologies — Final deployment website

Responsive static website with 19 HTML pages, accessible navigation, light/dark theme, functioning program filters, course recommendation tool, Google Maps previews, local SVG technology marks, WhatsApp enquiry flow, legal pages, SEO metadata, sitemap, PWA manifest, 404 page, and deployment configuration for Apache/cPanel, Netlify, and Vercel.

Open `index.html` for local preview. Read `DEPLOYMENT.md` before publishing.
