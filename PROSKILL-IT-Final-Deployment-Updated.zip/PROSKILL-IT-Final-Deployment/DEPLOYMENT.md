# Production deployment checklist

## Upload
Upload the contents of this directory to the public web root so `index.html` is at the domain root. Apache/cPanel can use the included `.htaccess`; Netlify and Vercel configuration files are also included.

## Before launch
1. Confirm the two campus addresses, map pins, telephone number, email, opening hours, founder details, course duration, prerequisites, fees, batch timings, and curriculum with management.
2. Replace or publish only verified student testimonials, trainer profiles, hiring partners, placement figures, salary figures, certification claims, and company logos.
3. Test every page on the production HTTPS domain.
4. Submit `/sitemap.xml` in Google Search Console.
5. Add an analytics platform only after consent/privacy requirements are reviewed.

## Enquiries
The counselling form validates entries in the browser and opens a pre-filled WhatsApp message to +91 90102 13122. It does not store personal information on the website. For CRM storage, replace the form handler in `assets/app.js` with your approved backend endpoint.

## Google Maps
Campus previews use embedded Google Maps queries. Confirm the exact business listing and replace each query with the verified place URL or coordinates when available.

## Cache
The included deployment headers cache assets for one year. Rename assets or add a version query after future changes.

## Update
- SVG icon reliability improved by embedding the icon sprite into each page and converting sprite links to local in-page references.
- Technology mark SVGs used across the site are now inlined in HTML for more reliable local preview and deployment rendering.
