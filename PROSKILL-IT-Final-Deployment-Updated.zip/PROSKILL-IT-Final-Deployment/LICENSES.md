# Asset and trademark notes

- The website layout, custom illustrations, custom technology marks, and code in this package were created for PROSKILL IT Technologies.
- Java, React, Python, AWS, Salesforce, Selenium, and other product names are trademarks of their respective owners. Their names are used only to describe technologies covered by training.
- Google Maps previews are embedded from Google Maps. Review Google's applicable terms and privacy requirements before production use.
- The package does not imply sponsorship, certification, partnership, or endorsement by any listed technology owner or employer.
